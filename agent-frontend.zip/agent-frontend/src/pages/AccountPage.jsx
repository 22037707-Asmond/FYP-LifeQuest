import React from 'react'
import AppNavBar from '../components/Account/AppNavBar'
import Sidebar from '../components/Account/Sidebar'
import Profile from '../components/Account/Profile'

export default function AccountPage() {
  return (
    <>
      <Profile />
    </>
  )
}
