package lifequest.backend.service;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lifequest.backend.dto.AgentSalesDTO;
import lifequest.backend.dto.SalesPerMonthDTO;
import lifequest.backend.dto.UserAgeBinDTO;
import lifequest.backend.dto.UserAgesDTO;
import lifequest.backend.dto.UserChildrenBinDTO;
import lifequest.backend.entity.Agent;
import lifequest.backend.entity.Premium;
import lifequest.backend.entity.Users;
import lifequest.backend.repository.AgentRepository;
import lifequest.backend.repository.PremiumRepository;
import lifequest.backend.repository.UsersRepository;

@Service
public class DataService {
    @Autowired
    private PremiumRepository premiumRepo;

    @Autowired
    private AgentRepository agentRepo;

    @Autowired
    private UsersRepository userRepo;

    public List<Premium> getAllPremiums() {
        return premiumRepo.findAll();
    }

    public List<Agent> getAllAgents() {
        return agentRepo.findAll();
    }

    public List<Users> getAllUsers() {
        return userRepo.findAll();
    }

    // Calculate age of users
    public List<UserAgesDTO> calculateUserAges() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        List<Users> users = userRepo.findAll();
        return users.stream()
                .map(user -> {
                    LocalDate birthDate = LocalDate.parse(user.getDateOfBirth(), formatter);
                    int age = Period.between(birthDate, LocalDate.now()).getYears();
                    return new UserAgesDTO(user.getFirstName(), age);
                })
                .collect(Collectors.toList());
    }

    // Calculate total sales made by each agent
    public List<AgentSalesDTO> calculateTotalSalesByAgent() {
    List<Premium> premiums = premiumRepo.findAll();
    Map<Agent, Double> salesByAgent = premiums.stream()
            .collect(Collectors.groupingBy(
                Premium::getAgent,
                Collectors.summingDouble(Premium::getAmount)
            ));

    return salesByAgent.entrySet().stream()
            .map(entry -> new AgentSalesDTO(entry.getKey().getFirstName(), entry.getValue()))
            .collect(Collectors.toList());
}

    // Calculate profit/loss for the month
    public Map<String, Double> calculateProfitOrLossByMonth() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM");
        LocalDate now = LocalDate.now();
        LocalDate startOfMonth = now.withDayOfMonth(1);
        
        // Collect all premiums
        List<Premium> premiums = premiumRepo.findAll();
        
        // Sum payments per month
        Map<String, Double> paymentsByMonth = new HashMap<>();
        for (Premium premium : premiums) {
            LocalDate purchaseDate = LocalDate.parse(premium.getPurchaseDate());
            while (purchaseDate.isBefore(now)) {
                String monthKey = purchaseDate.format(formatter);
                paymentsByMonth.put(monthKey, paymentsByMonth.getOrDefault(monthKey, 0.0) + premium.getAmount());
                purchaseDate = purchaseDate.plusMonths(1);
            }
        }

        // Sum salaries per month
        List<Agent> agents = agentRepo.findAll();
        Map<String, Double> salariesByMonth = new HashMap<>();
        for (Agent agent : agents) {
            LocalDate salaryDate = startOfMonth;
            while (salaryDate.isBefore(now)) {
                String monthKey = salaryDate.format(formatter);
                salariesByMonth.put(monthKey, salariesByMonth.getOrDefault(monthKey, 0.0) + agent.getSalary());
                salaryDate = salaryDate.plusMonths(1);
            }
        }

        // Calculate profit or loss per month
        Map<String, Double> profitOrLossByMonth = new TreeMap<>();
        for (String month : paymentsByMonth.keySet()) {
            double totalPayments = paymentsByMonth.get(month);
            double totalSalaries = salariesByMonth.getOrDefault(month, 0.0);
            profitOrLossByMonth.put(month, totalPayments - totalSalaries);
        }
        
        return profitOrLossByMonth;
    }

    // Agents data
    // Age demographics of clients per agent
    public List<UserAgeBinDTO> countUsersByAgeBin(Long agentId) {
        // Fetch premiums for the specific agent
        List<Premium> premiums = premiumRepo.findByAgentId(agentId);
    
        // Extract users who have had dealings with this agent
        List<Users> usersWithDealings = premiums.stream()
                .map(Premium::getUser)
                .distinct()
                .collect(Collectors.toList());
    
        // Define a date formatter to parse dates in the "dd/MM/yyyy" format
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    
        // Initialize age bins
        Map<String, Integer> ageBins = new HashMap<>();
        ageBins.put("0-18", 0);
        ageBins.put("19-30", 0);
        ageBins.put("31-45", 0);
        ageBins.put("46-60", 0);
        ageBins.put(">60", 0);
    
        // Group users into bins based on their age
        for (Users user : usersWithDealings) {
            try {
                LocalDate birthDate = LocalDate.parse(user.getDateOfBirth(), formatter);
                int age = Period.between(birthDate, LocalDate.now()).getYears();
    
                if (age >= 0 && age <= 18) {
                    ageBins.put("0-18", ageBins.get("0-18") + 1);
                } else if (age >= 19 && age <= 30) {
                    ageBins.put("19-30", ageBins.get("19-30") + 1);
                } else if (age >= 31 && age <= 45) {
                    ageBins.put("31-45", ageBins.get("31-45") + 1);
                } else if (age >= 46 && age <= 60) {
                    ageBins.put("46-60", ageBins.get("46-60") + 1);
                } else if (age > 60) {
                    ageBins.put(">60", ageBins.get(">60") + 1);
                }
            } catch (DateTimeParseException e) {
                // Handle the case where date parsing fails
                System.err.println("Date parsing error for user: " + user.getDateOfBirth() + " - " + e.getMessage());
            }
        }
    
        // Convert to DTOs
        return ageBins.entrySet().stream()
                .map(entry -> new UserAgeBinDTO(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
    }

    // Demographics of clients who have kids
    public List<UserChildrenBinDTO> countUsersByChildrenBin(Long agentId) {
        // Fetch premiums for the specific agent
        List<Premium> premiums = premiumRepo.findByAgentId(agentId);
    
        // Extract users who have had dealings with this agent
        List<Users> usersWithDealings = premiums.stream()
                .map(Premium::getUser)
                .distinct()
                .collect(Collectors.toList());
    
        // Initialize bins
        Map<String, Integer> childrenBins = new HashMap<>();
        childrenBins.put("0", 0);
        childrenBins.put("1-2", 0);
        childrenBins.put("3-4", 0);
        childrenBins.put(">5", 0);
    
        // Group users into bins based on number of children
        for (Users user : usersWithDealings) {
            int children = user.getChildren();
            if (children == 0) {
                childrenBins.put("0", childrenBins.get("0") + 1);
            } else if (children >= 1 && children <= 2) {
                childrenBins.put("1-2", childrenBins.get("1-2") + 1);
            } else if (children >= 3 && children <= 4) {
                childrenBins.put("3-4", childrenBins.get("3-4") + 1);
            } else if (children >= 5) {
                childrenBins.put(">5", childrenBins.get(">5") + 1);
            }
        }
    
        // Convert to DTOs
        return childrenBins.entrySet().stream()
                .map(entry -> new UserChildrenBinDTO(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
    }

    // Sales tracking per month
    public List<SalesPerMonthDTO> calculateSalesPerMonthForAgent(Long agentId) {
        List<Premium> premiums = premiumRepo.findByAgentId(agentId);  // Filter by agent
    
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
        DateTimeFormatter monthFormatter = DateTimeFormatter.ofPattern("yyyy-MM");
    
        Map<String, Double> salesPerMonth = premiums.stream()
                .collect(Collectors.groupingBy(
                        premium -> LocalDate.parse(premium.getPurchaseDate(), formatter).format(monthFormatter),
                        TreeMap::new,
                        Collectors.summingDouble(Premium::getAmount)
                ));
    
        return salesPerMonth.entrySet().stream()
                .map(entry -> new SalesPerMonthDTO(entry.getKey(), entry.getValue()))
                .collect(Collectors.toList());
    }
    
}