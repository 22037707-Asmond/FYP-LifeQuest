package lifequest.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import lifequest.backend.entity.Premium;

public interface PremiumRepository extends JpaRepository<Premium, Long> {
    
    List<Premium> findByAgentId(Long agentId);
}
