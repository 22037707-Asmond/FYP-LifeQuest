package lifequest.backend.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import lifequest.backend.dto.AgentSalesDTO;
import lifequest.backend.dto.SalesPerMonthDTO;
import lifequest.backend.dto.UserAgeBinDTO;
import lifequest.backend.dto.UserAgesDTO;
import lifequest.backend.dto.UserChildrenBinDTO;
import lifequest.backend.service.DataService;

@RestController
@RequestMapping("/api/data")
public class DataController {

    @Autowired
    private DataService dataService;

    // Endpoint to get the age of users
    @GetMapping("/user-ages")
    public List<UserAgesDTO> getUserAges() {
        return dataService.calculateUserAges();
    }

    // Endpoint to get total sales by each agent
    @GetMapping("/agent-sales")
    public List<AgentSalesDTO> getAgentSales() {
        return dataService.calculateTotalSalesByAgent();
    }

    // Endpoint to get profit or loss by month
    @GetMapping("/profit-loss")
    public Map<String, Double> getProfitOrLossByMonth() {
        return dataService.calculateProfitOrLossByMonth();
    }

    // Endpoint to get age demographics for a specific agent
    @GetMapping("/age-demographics/{agentId}")
    public List<UserAgeBinDTO> getAgeDemographics(@PathVariable Long agentId) {
        return dataService.countUsersByAgeBin(agentId);
    }

    // Endpoint to get children demographics for a specific agent
    @GetMapping("/children-demographics/{agentId}")
    public List<UserChildrenBinDTO> getChildrenDemographics(@PathVariable Long agentId) {
        return dataService.countUsersByChildrenBin(agentId);
    }

    // Endpoint to get sales tracking per month for a specific agent
    @GetMapping("/sales-per-month/{agentId}")
    public List<SalesPerMonthDTO> getSalesPerMonth(@PathVariable Long agentId) {
        return dataService.calculateSalesPerMonthForAgent(agentId);
    }
}
