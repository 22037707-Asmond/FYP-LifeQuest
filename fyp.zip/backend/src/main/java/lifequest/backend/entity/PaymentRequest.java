// package lifequest.backend.entity;

// public class PaymentRequest {
//     private Long userId;
//     private Long insuranceId;
//     private double totalAmount;
//     private String currency;
//     private String method;

//     // Getters and Setters
//     public Long getUserId() {
//         return userId;
//     }

//     public void setUserId(Long userId) {
//         this.userId = userId;
//     }

//     public Long getInsuranceId() {
//         return insuranceId;
//     }

//     public void setInsuranceId(Long insuranceId) {
//         this.insuranceId = insuranceId;
//     }

//     public double getTotalAmount() {
//         return totalAmount;
//     }

//     public void setTotalAmount(double totalAmount) {
//         this.totalAmount = totalAmount;
//     }

//     public String getCurrency() {
//         return currency;
//     }

//     public void setCurrency(String currency) {
//         this.currency = currency;
//     }

//     public String getMethod() {
//         return method;
//     }

//     public void setMethod(String method) {
//         this.method = method;
//     }
// }
