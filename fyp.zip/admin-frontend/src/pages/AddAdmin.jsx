import AddAdmin from '../Components/Updates/AddAdmin';
import 'bootstrap/dist/css/bootstrap.min.css';

const SignInPage = () => {
    return (
       <>
         <AddAdmin />
       </>
    );
};

export default SignInPage;