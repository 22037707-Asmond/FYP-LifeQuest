import SignIn from '../Components/Updates/SignIn';
import 'bootstrap/dist/css/bootstrap.min.css';

const SignInPage = () => {
    return (
       <>
         <SignIn />
       </>
    );
};

export default SignInPage;