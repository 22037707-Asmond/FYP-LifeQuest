import { Box } from "@mui/material";
import Header from "../../Components/PageFragment/Header";

const Line = () => {
    return(
        <Box m="20px">
            <Header title="Paypal Payment" subtitle="Pay Salary Agents"/>
            <Box>
                
            </Box>
        </Box>
    )
}

export default Line;