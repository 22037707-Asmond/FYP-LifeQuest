import React from 'react';
import AppNavBar from '../components/Account/AppNavBar'
import AgentCalendar from '../components/Calendar/CalendarAgent'

export default function Calendar() {
  return (
    <>
      <AgentCalendar />
    </>
  );
}
