import React from 'react'
import AppNavBar from '../components/Account/AppNavBar'
import Sidebar from '../components/Account/Sidebar'
import BarChart from '../components/Charts/BarChart'
import LineChartSales from '../components/Charts/LineChartSales'
import PieChartAge from '../components/Charts/PieChartAge'
import Profile from '../components/Account/Profile'

export default function AccountPage() {
  return (
    <>
      <Profile />
    </>
  )
}
